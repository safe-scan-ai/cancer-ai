import os
import pandas as pd
from pathlib import Path

# Paths
base_dir = Path(__file__).parent
images_dir = base_dir / 'images'
labels_file = base_dir / 'labels.csv'

# Get list of image files
image_files = set(f.name for f in images_dir.glob('*.jpg'))
print(f"Found {len(image_files)} images in {images_dir}")

# Read labels file
df = pd.read_csv(labels_file)
print(f"Found {len(df)} entries in {labels_file}")

# Check for missing images
missing_images = []
for idx, row in df.iterrows():
    img_name = Path(row['image']).name
    if img_name not in image_files:
        missing_images.append((idx, img_name))
        print(f"Missing image: {img_name} (row {idx+2})")

print(f"\nFound {len(missing_images)} missing images")

# Check for missing entries in labels.csv
missing_entries = []
for img in image_files:
    if not any(img in path for path in df['image']):
        missing_entries.append(img)
        print(f"Missing entry for image: {img}")

print(f"\nFound {len(missing_entries)} images not in labels.csv")

# Fix the labels file if needed
if missing_images or missing_entries:
    # Remove rows with missing images
    df = df[~df['image'].apply(lambda x: Path(x).name in [m[1] for m in missing_images])]
    
    # Add missing entries with BENIGN label
    for img in missing_entries:
        df = pd.concat([df, pd.DataFrame([{'image': f'images/{img}', 'label': 'BENIGN'}])], 
                      ignore_index=True)
    
    # Save fixed file
    fixed_file = base_dir / 'labels_fixed.csv'
    df.to_csv(fixed_file, index=False)
    print(f"\nSaved fixed labels to: {fixed_file}")
    print(f"Original entries: {len(df) - len(missing_entries)}")
    print(f"Added entries: {len(missing_entries)}")
else:
    print("\nAll image files are properly referenced in labels.csv")
